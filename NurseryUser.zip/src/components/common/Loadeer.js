import React from 'react'
export default function Loadeer() {
    return (
        <div className="loader">
            <img src="https://i.gifer.com/ZdPH.gif" alt='Loader' />
        </div>)
}
